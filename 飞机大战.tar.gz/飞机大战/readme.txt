飞机大战部署步骤
1.从github上拉去代码到root下
2.解压PlaneWar-Qt文档
3.在终端打开  飞机大战启动引导（./飞机大战启动引导）
4.运行root下的 plane

注意：源码目录在PlaneWar-Qt中
